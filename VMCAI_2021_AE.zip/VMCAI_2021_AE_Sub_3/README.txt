Artifact evaluation for the paper submission 14, VMCAI 2021. 

<< A Synchronous Effects Logic for Temporal Verification of Pure Esterel >>

STEP 1:  Please find the deb files we provided: 
         "syncedeffects_20201025-1_amd64.deb" and 
         "menhir_20200123-2_amd64.deb"

STEP 2:  To install the deb package:
   
   a) sudo dpkg -i menhir_20200123-2_amd64.deb
      sudo dpkg -i syncedeffects_20201025-1_amd64.deb
      
      (The source code and test suits are in the folder "SyncedEffects"
       You can also download the code from Github by: 
       git clone https://github.com/ForPaperReview/SyncedEffects.git )

    
   b) By then, you should be able to get 3 executables: hip, sleek and ltl  
      Test it by typing in the terminal:

      which hip 
      which sleek
      Which ltl
 
   d) To test the 3 parts of functionalities, which are claimed in the paper:
      
      PART 1: < Temporal verification for Esterel programs > 
              Implemented mainly in SyncedEffects/FrontEnd/Forward.ml
              We provide 96 test programs (including the stress tests) in 
              the folder "SyncedEffects/src/programs/", we index them with a prefix number from 0 to 95. 
   
           Example 1: presented in the paper section 2 Overview, execute:

             hip SyncedEffects/src/programs/0_verview.txt

             (You will see the verification results printed for 2 Module: close and menager)
 
           Example 2: presented in the paper section 1 introduction, logical incorrect case, execute:

             hip SyncedEffects/src/programs/19_intruduction2.txt
   
             (You will see the verification stopped at stage 1, and prints "logical incorrect")

           Example 3: presented in the paper section 6.1 and 6.2, for the loop invariants, execute:
            
             hip SyncedEffects/src/programs/1_loop.txt
             hip SyncedEffects/src/programs/2_loop.txt

             (You will see the verification both succeed with different results printed)

           
           Example 4: presented in the paper section 6.4

             hip SyncedEffects/src/programs/71_a_bug_found.txt

             (You will see our implementation is able to soundly accept the program,
              while it was a false positive error program detected by prior work)


           The rest... You can test other programs if you want, 
           but the naming of the files does not always corresponds to the program it contains...
 

       PART 2: < The term rewriting system for effects entailments checking > 
              This is a back end solver, supporting the above mentioned verification process.
              Implemented mainly in SyncedEffects/BackEnd/Rewriting.ml
              We provide a bunch of test entailments in 
              the folder "SyncedEffects/src/effects/". 

              Example 1: Effects concatenation: 
   
                 sleek SyncedEffects/src/effects/Concate_1.ee
               
                 (You will see, for each of the effects entailments, 
                  we print a result of the entailments proof, and its proof trees)

              Example 2: Effects disjunctions: 
   
                 sleek SyncedEffects/src/effects/Disjunction_both.ee        
             
              Example 3: Effects infinite traces: 
   
                 sleek SyncedEffects/src/effects/Omega_1.ee      

              The rest... You can test other files if you want. 


        PART 3: < LTL to Effects Translator > 
              This is supporting the paper section 5.2, 
              Implemented mainly in SyncedEffects/LTL_Traslator.ml
              to show the expressiveness of our effects (as the specification language)


              Example 1: paper example

                 ltl SyncedEffects/src/ltl/paper_example.ltl

              
      
Above, 

for more information/instruction, you can find it from https://github.com/ForPaperReview/SyncedEffects. 
      
Lastly, thank you so much for your time and patience. 




Best,


